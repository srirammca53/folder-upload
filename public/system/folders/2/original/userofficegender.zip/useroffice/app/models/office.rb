class Office < ActiveRecord::Base
end
