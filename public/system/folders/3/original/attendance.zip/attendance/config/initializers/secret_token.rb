# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Attendance::Application.config.secret_token = 'de5a30e4c74d6c00f38d34a4451eb97b593026991a65d873f2dd1bf1a9fcfb22fc7eab3eb2312d3a3100a5688b0e738e91eb8c5c1bb4600cd6dc62066db10b86'
