class UpdatesController < ApplicationController
def create
    @register = Register.find(params[:register_id])
    @update = @register.update.create(params[:update])
    redirect_to update_path(@update)
  end
 def new
    @update = Update.new
@update = @register.update.create(params[:update])
   redirect_to update_path(@update)
  end
def show
    @register = Register.find(params[:id])
      redirect_to registers_path(@update)
    end
end
