class Register < ActiveRecord::Base
has_one :department
end
