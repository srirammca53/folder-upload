class Update < ActiveRecord::Base
belongs_to :register
end
