module UpdatesHelper
end
