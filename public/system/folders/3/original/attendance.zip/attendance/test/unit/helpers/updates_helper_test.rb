require 'test_helper'

class UpdatesHelperTest < ActionView::TestCase
end
